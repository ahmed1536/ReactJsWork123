import { useState } from "react";
import React  from "react";

function TextForm(props){

    const [text,settext] = useState("Please Enter Something... !")
   
     const handleClick = () => {
        console.log("Function button is clicked!")
        let newText = text.toUpperCase();
        settext(newText);
    }

    const handle_Lower =() =>{
        console.log("Handle Lower is clicked!");
        let newlower = text.toLowerCase();
        settext(newlower);
    } 

    const handleClear = () =>{

        console.log('error hai')
        let clear1 = '';
        settext(clear1)
    }

    const handleOnChange = (event) =>{
        settext(event.target.value)
        console.log("Handle On Change function")
    }

    return (
        <>
        
        <body>
        <div className="container">
                <div className="mb-3">
                <center>
                    <h2 for="textdata" className="form-label my-3">{props.title}</h2>
                </center>

                <textarea className="form-control" onChange={handleOnChange} value={text} id="textdata" rows="8"></textarea>
                </div>

                <button className="btn btn-primary btn-sm" onClick={handleClick}>Convert to Uppercase</button> &nbsp;
                <button className="btn btn-primary btn-sm" onClick={handle_Lower}> Convert to Lowercase</button>
                <button className="btn btn-success mx-2 btn-sm" onClick={handleClear}> Clear </button>

        
            <h4 style={{marginTop:"4%"}}> Your Text Word History</h4>
            <h6 style={{fontSize:"13px"}}> {text.split(" ").length} words and {text.length} character </h6>
            <h6 style={{fontSize:"13px"}}> {0.008 * text.split(" ").length} Minutes to Read</h6>

        </div>

        </body>
        </>

    );

}

export default TextForm;