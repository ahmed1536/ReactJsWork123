import React, { useState} from 'react'

function Counterapp (props){

    const [count,set_count] = useState(0)
    const [inputvalue,setinputvalue] = useState("");

    const handleChange = (event) =>{
        setinputvalue(event.target.value)
    }

    const handleincrement = () => {
         set_count(count+1)
    }

    const handledecrement = () =>{
        set_count(count-1)
    }

    const handleclick = () =>{
       
        set_count(parseInt(inputvalue))
        
    }
    
    const handlereset =() =>{
        set_count(0)
    }

   
    return(
        <>

    <div class='container my-3' >
        
    <center>

        <h1 className='my-3'>{props.title}</h1>
        <br></br>
        <h5 style={{float:"left"}}>Enter Initial Value: </h5> 

        <div class="input-group" >
            <input type="text" value={inputvalue} onChange={handleChange} class="form-control"/>
            <button className='btn btn-primary' onClick={handleclick}>Add Me!</button>
        </div>
     
    </center>

    <h4 style={{marginTop:"4%"}}>Current Count: {count}</h4>

        <button className='btn btn-primary btn-sm mx-2' onClick={handleincrement}> Increment</button>
        <button className='btn btn-danger btn-sm' onClick={handledecrement}> Decrement</button>
        <button className='btn btn-secondary btn-sm mx-2' onClick={handlereset}> Reset </button> 
           

</div>

</>

    );
}

export default Counterapp
