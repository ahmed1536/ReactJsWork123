import React, { useState } from 'react'

function TipCalculator (props){

const [bill,setbill]= useState(0)
const [tip,settip] = useState(0)
const [split_bill,setsplit_bill]=useState(0)  
const [message,setmessage]=useState()
const [totalamount,settotalamount]=useState()


const handleincrement = () =>{
settip(tip+1)
}
const handledecrement =()=>{
    settip(tip-1)
}
const handleincrement1= ()=>{
setsplit_bill(split_bill+1)
}
const handledecrement1 =()=>{
    setsplit_bill(split_bill-1)
}
const handleonChange= (event)=>{
setbill(event.target.value)
}



const handlecalculate=()=>{

    const tip1=parseInt(bill * (tip/100))
    console.log(typeof(tip1))
    setmessage(tip1)
    settotalamount(tip1+bill)
 
}

    return(
        <>

<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous"/>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    
</head>

<body>

    <div class="container-fluid" 
    style={{width:"500px",backgroundColor:"",boxShadow:""}}>
    <center> <h2 style={{borderRadius:'3%', border:"1px solid black"}} className='my-3'>{props.title}</h2></center>

    <div class="row">
        <div class="col">
            <label><b>Bill Amount</b></label>
            <input type='text' onChange={handleonChange} class="form-control" value={bill}  />
        </div>
    </div>

    <div class="row">
        <div class="col">
            <label><b>Tip%</b> </label>
            &nbsp; <button class="btn btn-primary btn-sm my-3" onClick={handleincrement}>+</button> &nbsp;
            <input type='text' value={tip} style={{width:"50px"}} /> &nbsp;

            <button class="btn btn-danger btn-sm" onClick={handledecrement}>-</button>
        </div>

        <div class="col">
        <label><b>Split the Bill</b> </label>
            &nbsp; <button class="btn btn-primary btn-sm my-3" onClick={handleincrement1}>+</button> &nbsp;
            <input type='text' value={split_bill} style={{width:"50px"}} /> &nbsp;
            <button class="btn btn-danger btn-sm" onClick={handledecrement1}>-</button>
        </div>
    </div>

    <div class="row my-3">
        <div class="col">
            <button class="btn btn-lg btn-success">Clear</button>
        </div>

        <div class="col">
            <button class="btn btn-lg btn-primary" onClick={handlecalculate}>Calculate</button>
        </div>
    </div>

        <br/>
    <hr/>

    <div class="row" style={{marginTop:"6%"}}>
    <center>
        <h5 style={{float:"left"}}> Tip Amount : &nbsp; 
        <span style={{fontSize:"16px"}}>Rs/-</span> {message}  </h5>
        <br/>
    </center> 
    </div>

    <div class="row" style={{marginTop:"1%"}}>
    <center>
        <h5 style={{float:"left"}}> Total Bill Amount : &nbsp;
         <span style={{fontSize:"16px"}}>Rs/-</span> {totalamount}  </h5>
        <br/>
    </center> 
    </div>

        
    </div>   

</body>

</html>


        </>

    );

}
export default TipCalculator