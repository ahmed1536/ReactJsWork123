import React, { useState } from "react";

function BmiCalculator(props){

const [intitalweight,setweight] = useState(0)
const [initialheight,setheight] = useState(0)
const [initialinch,set_inch] = useState(0)
const [bmi,setbmi] = useState('Your BMI is :')
const [message,setbmimessage] = useState()

const data= initialheight*30.48+initialinch*2.54
const data_to_meter =data /100
const result=intitalweight/(data_to_meter*data_to_meter)


const tocalcaculate = () =>{
    
if(result<18.5){
    setbmi(result.toFixed(1))
    setbmimessage('You Are Underweight')
}

else if(result>=18.5 && result<24.9){
    setbmi(result.toFixed(1))
    setbmimessage('Your Weight is Normal')
}

else if(result>=25 && result<29.9){
    setbmi(result.toFixed(1))
    setbmimessage('You are Over-weight')
}
else{
    setbmi(result.toFixed(1))
    setbmimessage('Obesity')
}


}

    return(
        <>

    <html>
     
    <body style={{display:"flex",backgroundColor:"black", margin:"0px", height:"100%", width:"100%",padding:"0px"}}>
               
<div class="container-fluid" style={{width:"450px", backgroundColor:"white", marginTop:"2%",borderRadius:"10px"}}>
    <h1 style={{textAlign:"center",color:"black"}}>{props.title}</h1>
               
<div class="row">
    <div class="col">
        <label> <b>Weight(KG) </b></label>
        <input type="number" value={intitalweight} onChange={(event) => setweight(event.target.value)}
        style={{padding:"5px", boxShadow:"2px 2px 2px #acaebd"}}class="form-control" name="weight"/>
    </div>
</div> 

<div class="row">
    <div class="col">
    <label><b>Weight (Pounds)</b></label>
        <input type="text" value={intitalweight*2.205} style={{padding:"5px", boxShadow:"2px 2px 2px #acaebd"}}class="form-control" disabled/>
    </div>  
    
</div>

<div class="row">
    <div class="col">
        <label> <b>Height(Feet) </b></label> 
        <input type="number" value={initialheight} onChange={(event) => setheight(event.target.value) } style={{width:"200px", boxShadow:"2px 2px 2px #acaebd"}} class="form-control" name="heightinfeet"/>
    </div>

    <div class="col">
        <label> <b>Height(Inc) </b></label>  
        <input type="number" value={initialinch} onChange={(event)=> set_inch(event.target.value)} style={{width:"200px", boxShadow:"2px 2px 2px #acaebd" }} class="form-control" name="heightinInches" />
    </div>
</div>

<div class="row">
<div class="col">
<label><b>Ft+inches to cm</b></label>
        <input type="text" value={data}  style={{padding:"5px", boxShadow:"2px 2px 2px #acaebd"}}class="form-control" disabled/>
    </div>
</div>

<div class="row">
<div class="col">
<label><b>CM to M</b></label> 
        <input type="text" value={data_to_meter} style={{padding:"5px", boxShadow:"2px 2px 2px #acaebd"}}class="form-control" disabled/>
    </div>
</div>


<button class="btn btn-primary btn-lg my-3" onClick={tocalcaculate} style={{width:"100%"}}>Calculate</button>

<div style={{height:"150px",width:"100%"}}>
    <center>
    <h5> {bmi} </h5>
    <h5> {message} </h5>
    </center>
</div>

   

 </div>

 </body>
 </html>

</>
);

}
export default BmiCalculator