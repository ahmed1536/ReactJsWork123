import logo from './logo.svg';
import './App.css';
import Navbar from './Components/Navbar/Navbar';
import TextForm from './Components/TextForm/Textform';
import Counterapp from './Components/CounterApp/Counterapp';
import Design from './Components/NftDesign/Design';
import BmiCalculator from './Components/BmiCalculator/BmiCalculator'
import TipCalculator from './Components/TipCalculator/TipCalculator';



function App() {
  return (
    <>
    
    <div>
    {/* <TextForm title="Word Counter"/> */}

     {/* <Counterapp title='Counter App'/>  */}
 
     {/* <Design />  */}

    {/* <BmiCalculator title="BMI CALCULATOR"/>
     */}

     <TipCalculator title="TIP CALCULATOR"/>

    </div>
    
    </>

  );
}

export default App;
